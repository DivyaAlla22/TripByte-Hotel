package com.tripbyte.hotel.exception;

/**
 * @author Simpson Alfred
 */

public class PhotoRetrievalException extends RuntimeException {
    public PhotoRetrievalException(String message) {
        super(message);
    }
}